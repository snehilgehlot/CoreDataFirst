//
//  AddViewController.swift
//  CoreData Sample
//
//  Created by Manish Pathak on 09/01/18.
//  Copyright © 2018 snehil. All rights reserved.
//

import UIKit
import CoreData

class AddViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var txtName:UITextField!
    @IBOutlet var txtSurName:UITextField!
    var people: [NSManagedObject] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
     }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
     }
    override var prefersStatusBarHidden: Bool
        {
        return true
    }
    
    @IBAction func btnBack(_sender:UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSubmit(_ sender:UIButton)
    {
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        // 1
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        // 2
        let entity =
            NSEntityDescription.entity(forEntityName: "Person",
                                       in: managedContext)!
        
        let person = NSManagedObject(entity: entity,
                                     insertInto: managedContext)
        
        // 3
        person.setValue(self.txtName.text, forKeyPath: "name")
        person.setValue(self.txtSurName.text, forKeyPath: "surname")
        
        // 4
        do {
            try managedContext.save()
            self.navigationController?.popViewController(animated: true)
            //people.append(person)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
        
    }
    
}
