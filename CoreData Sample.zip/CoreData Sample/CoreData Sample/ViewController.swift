//
//  ViewController.swift
//  CoreData Sample
//
//  Created by Manish Pathak on 09/01/18.
//  Copyright © 2018 snehil. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var people: [NSManagedObject] = []
    @IBOutlet var tblPeople: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view, typically from a nib.
    }
    override var prefersStatusBarHidden: Bool
        {
         return true
      }
    
    override func viewWillAppear(_ animated: Bool) {
        self.fetchRequest()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func  btnAdd(_ sender:UIButton)
    {
        let secondviewController:UIViewController =  (self.storyboard?.instantiateViewController(withIdentifier: "AddViewController") as? AddViewController)!
        self.navigationController?.pushViewController(secondviewController, animated: true)
    }
    @IBAction func btnBack(_ sender:UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    func  fetchRequest()
    {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        //2
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "Person")
        
        //3
        do {
            people = try managedContext.fetch(fetchRequest)
            self.tblPeople.reloadData()
            
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    //MARK: - TableViewDelegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 76.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddCell") as! AddCell
        let person =  people[indexPath.row]
        cell.lblName.text = person.value(forKey: "name") as? String
        cell.lblSurName.text = person.value(forKey: "surname") as? String
        return cell
        
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.delete) {
            
          
            
            
            guard let appDelegate =
                UIApplication.shared.delegate as? AppDelegate else {
                    return
            }
            
            let managedContext =
                appDelegate.persistentContainer.viewContext
                managedContext.delete(people[indexPath.row])
                people.remove(at: indexPath.row)
            do {
                try managedContext.save()
            } catch _ {
            }
                self.tblPeople.reloadData()
            
            // handle delete (by removing the data from your array and updating the tableview)
        }
    }
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//
//        people.remove(at: indexPath.row)
//        self.tblPeople.reloadData()
//    }
    
}

