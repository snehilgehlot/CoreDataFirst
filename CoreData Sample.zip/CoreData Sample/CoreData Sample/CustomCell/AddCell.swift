//
//  AddCell.swift
//  CoreData Sample
//
//  Created by Manish Pathak on 09/01/18.
//  Copyright © 2018 snehil. All rights reserved.
//

import UIKit

class AddCell: UITableViewCell {
    
    @IBOutlet var lblName:UILabel!
    @IBOutlet var lblSurName:UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
